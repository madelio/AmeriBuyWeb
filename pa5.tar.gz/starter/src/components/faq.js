import React from 'react';

export default class FAQ extends React.Component {
	render() {
		return (
			<h1>This is FAQ.js</h1>
		);
	}
}
