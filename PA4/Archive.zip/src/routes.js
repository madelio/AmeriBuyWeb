import React from 'react';
import { Route, IndexRoute } from 'react-router';
import App from './components/app';
import HomePage from './components/home';
import FAQ from './components/faq';
import login from './components/login';
import signup from './components/signup';
import AccountPage from './components/AccountPage';
import AccountInfo from './components/AccountInfo';
import OrderHistory from './components/OrderHistory.js';
import Checkout from './components/Checkout.js';
import AddItem from './components/AddItem.js';

export default (
	<Route path="/" component={App}>
		<IndexRoute component={HomePage}/>
		<Route path="faq" component={FAQ}/>
		<Route path="login" component={login}/>
		<Route path="signup" component={signup}/>
		<Route path="account" component={AccountPage}>
			<IndexRoute component={AccountInfo}/>
		</Route>
		<Route path="account/orders" component={OrderHistory}/>
		<Route path="checkout" component={Checkout}/>
		<Route path="addItem" component={AddItem}/>
	</Route>
);